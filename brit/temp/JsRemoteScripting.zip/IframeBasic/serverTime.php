<?php
    $msg = date('H:i');

    $msg = 'a\na';
    header("Content-Type: text/html; charset=iso-8859-2");
    echo '<script>window.parent.responseHandler("'.htmlspecialchars($msg).'")</script>';
?>