<?php
    if (isset($_POST['varName'])) {
        if (isset($_SERVER[$_POST['varName']])) {
            $msg = $_SERVER[$_POST['varName']];
        } else {
            $msg = 'Hiba: nincs ilyen nev� szerver v�ltoz�!';
        }
    } else {
        $msg = 'Hiba: a szerver v�ltoz� nev�t meg kell adni!';
    }

    header("Content-Type: text/html; charset=iso-8859-2");
    echo '<script>window.parent.responseHandler("'.htmlspecialchars($msg).'")</script>';
?>