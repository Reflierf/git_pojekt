<?php
    function valueToJsValue($value, $encoding = false)
    {
        if (!is_numeric($value)) {
            $value = str_replace('\\', '\\\\', $value);
            $value = str_replace('"', '\"', $value);
            $value = '"'.$value.'"';
        }
        if ($encoding) {
            switch ($encoding) {
                case 'utf-8' :
                    return iconv('ISO-8859-2', 'UTF-8', $value);
                    break;
            }
        } else {
            return $value;
        }
    }

    function arrayToJsArray( $array, $name, $nl = "\n", $encoding = false ) {
        if (is_array($array)) {
            $jsArray = $name.' = new Array();'.$nl;
            foreach($array as $key => $value) {
                switch (gettype($value)) {
                    case 'unknown type':
                    case 'resource':
                    case 'object':
                        break;
                    case 'array':
                        $jsArray .= arrayToJsArray($value, $name.'['.valueToJsValue($key, $encoding).']', $nl);
                        break;
                    case 'NULL':
                        $jsArray .= $name.'['.valueToJsValue($key, $encoding).'] = null;'.$nl;
                        break;
                    case 'boolean':
                        $jsArray .= $name.'['.valueToJsValue($key, $encoding).'] = '.($value ? 'true' : 'false').';'.$nl;
                        break;
                    case 'string':
                        $jsArray .= $name.'['.valueToJsValue($key, $encoding).'] = '.valueToJsValue($value, $encoding).';'.$nl;
                        break;
                    case 'double':
                    case 'integer':
                        $jsArray .= $name.'['.valueToJsValue($key, $encoding).'] = '.$value.';'.$nl;
                        break;
                    default:
                        trigger_error('Hoppa, egy �j t�pus a PHP-ben? '.__CLASS__.'::'.__FUNCTION__.'()!', E_USER_WARNING);
                }
            }
            return $jsArray;
        } else {
            return false;
        }
    }
?>