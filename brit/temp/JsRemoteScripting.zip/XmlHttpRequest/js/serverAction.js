serverAction = new Object();
serverAction.requestHandler = null;
serverAction.callHandler = function(result) {
    if (result.errorCode == -1) {
        alert(result.errorMsg);
    } else {
        if (this.requestHandler) {
            var tempHandler = this.requestHandler;
            this.requestHandler = null;
            tempHandler(result);
        }
    }
}

serverAction.createNVArray = function(name, value) {
    var data = new Array();
    data['name'] = name;
    data['value'] = value;
    return data;
}

serverAction.call = function(action, data, requestHandler) {
    var params;

    params = '__action__=' + action;
    for(var i = 0; i < data.length; i++) {
        params += '&' + data[i].name + '=' + encodeURIComponent(data[i].value);
    }
    
    var xmlHttp = XmlHttp.create();
    xmlHttp.open('POST', 'serverActionHandler.php', true);
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4) {
            var result = new Array();
            eval(xmlHttp.responseText);
            serverAction.callHandler(result);
        }
    }
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=utf-8');
    xmlHttp.send(params);
    this.requestHandler = requestHandler;
}