<?php
    include_once('include/arrayToJsArray.php' );
    define('NL', "\n");
  
    foreach( $_POST as $name => $value ) {
        $_POST[$name] = iconv('UTF-8', 'ISO-8859-2' , $value);
    }
  
    $result = array();
    $result[ 'errorCode' ] = 0;
    $result[ 'errorMsg' ] = '';
  
    if (isset($_POST['__action__'])) {
        if (file_exists('action/'.$_POST['__action__'].'.php')) {
            ob_start();
            include('action/'.$_POST['__action__'].'.php');
            $error = ob_get_contents(); 
            ob_end_clean();
            if ($error != '') {
                // Ide j�het egy�b hibakezel�s (pl.: loggol�s)
                $result['errorCode'] = -2;
                $result['errorMsg'] = 'A ( '.$_POST['__action__'].') parancs v�grehajt�sa k�zben hiba t�rt�nt!';
            }
        } else {
            $result['errorCode'] = -1;
            $result['errorMsg'] = 'Ilyen parancs ( '.$_POST['__action__'].') nem l�tezik!';
        }
    }
  
    // Szok�sos cachel�st megakad�lyoz� fejl�cek
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
    header('Last-Modified: '.gmdate('D, d M Y H:i:s' ).' GMT');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
    // V�lasz t�pus�nak be�ll�t�sa
    header('Content-type: text/plain; charset=utf-8');
    echo arrayToJsArray($result, 'result', NL, 'utf-8');
?>