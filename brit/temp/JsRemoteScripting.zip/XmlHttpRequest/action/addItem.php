<?php
    if (isset($_POST['itemName'])) {
        $_POST['itemName'] = trim($_POST['itemName']);
        if ($_POST['itemName'] != '') {
            if ($_POST['itemName'] == '�rv�zt�r� t�k�rf�r�g�p') {
                $result['errorCode'] = 3;
                $result['errorMsg'] = "�reg, ez m�r nagyon elcs�pelt!";
            } else {
                // Itt t�rt�nhet mondjuk az adatb�zisba val� r�gz�t�s
                $result[ 'itemName' ] = $_POST['itemName'].' (felv�ve)';
            }
        } else {
            $result['errorCode'] = 2;
            $result['errorMsg'] = "Az elem neve nem megfelel�!";
        }
    } else {
        $result['errorCode'] = 1;
        $result['errorMsg'] = "Az elem nev�t k�telez� megadni!";
    }
?>