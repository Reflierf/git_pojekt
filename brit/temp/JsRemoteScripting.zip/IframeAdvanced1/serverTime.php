<?php
    $msg = date('H:i');

    header("Content-Type: text/html; charset=iso-8859-2");
    echo '<script>window.parent.responseHandler("'.htmlspecialchars($msg).'")</script>';
?>