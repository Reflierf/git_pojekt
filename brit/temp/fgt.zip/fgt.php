<?php
header('Content-Type: text/html; charset=utf-8');
$time_start = microtime(true); //string
$start_time = round($time_start*1000);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Kerekített doboz, Letölt</title>
<style type="text/css" media="screen">
html, body{margin:0;border-style:none;padding:0;background-color:#CECECE;
           font-family:Verdana, sans-serif;font-size:12px;color:#111F10;text-align:center;}
/* oldal háttér és keret */
#oldal-hatter{position:fixed;left:0;top:0;width:100%;height:100%;z-index:100;}
#oldal-keret{position:absolute;left:0;top:0;min-width:1218px;overflow:auto;width:100%;height:100%;
             z-index:300;background-color:transparent;margin:0;padding:0;border-style:none;}
#fodiv{
  background-color: transparent;
  width: 80%;
  height: auto;
  position:relative;
  margin-left: -40%;
  left: 50%;
  // margin-left: 0;
  // left: 0;
}
/* kerekített szerkezet kezdete */
#head_kozep{
	background-image: url('images/Alak-13_02.png'); /* font_kozep 1*49px kép */
	background-position: right bottom;
	background-repeat: repeat-x;
	width: auto;
	height: 49px;
  width: 80%;
  margin:0 auto
}
#head_bal{
	background-image: url('images/Alak-13_01.png'); /* font_bal 66*49px kép */
	background-position: left bottom;
	background-repeat: no-repeat;
	width: 66px;
	height: 49px;
  float:left;
  margin-left:-66px;
}
#head_jobb{
	background-image: url('images/Alak-13_03.png'); /* font_jobb 55*49px kép */
	background-position: left bottom;
	background-repeat: no-repeat;
	width: 66px;
	height: 49px;
  float:right;
  margin-right:-66px;
}
#kozep_tartalom{
	background-image: url('images/Alak-13_05.png'); /* kozep_kozep 1*1px kép */
	background-position: right;
	background-repeat:repeat;
	width: auto;
	height: auto;
  position:relative;
  width: 80%;
  margin:0 auto;
/*border:1px solid brown;*/
}
#kozep_bal{
	background-image: url('images/Alak-13_04.png'); /* kozep_bal 66*1px kép */
	background-position: right;
	background-repeat:repeat-y;
	width: 66px;
  height:100%;
  position:absolute;
  top:0;
  bottom:0;
  left:-66px;
}
#kozep_jobb{
	background-image: url('images/Alak-13_06.png'); /* kozep_jobb 55*1px kép */
	background-position: left;
	background-repeat:repeat-y;
	width: 66px;
  height:100%;
  position:absolute;
  top:0;
  bottom:0;
  right:-66px;
}
#footer_kozep{
	background-image: url('images/Alak-13_08.png'); /* lent_kozep 1*61px kép */
	background-position: right top;
	background-repeat: repeat-x;
	height: 49px;
  width: 80%;
  margin:0 auto;
}
#footer_bal{
	background-image: url('images/Alak-13_07.png'); /* lent_bal 66*61px kép */
	background-position: right top;
	background-repeat: no-repeat;
	width: 66px;
	height: 49px;
  float:left;
  margin-left:-66px;
}
#footer_jobb{
	background-image: url('images/Alak-13_09.png'); /* lent_jobb 55*61px kép */
	background-position: left top;	
	width: 66px;
	height: 49px;
	background-repeat: no-repeat;
  float:right;
  margin-right:-66px;
}
/* kerekített szerkezet vége */
.clear{clear:both;}

/* menü felbukkanó kép */
 ul{list-style-type:none;}
ul li a{
  position:relative;
  display: block;
  margin: 0;
  padding:0;
  text-align:center;
  width:100px;
}
.bukkan1, .bukkan2, .bukkan3{
  position:absolute;
  left:105px;
  top:0;
  width:250px; 
  height:157px; 
  visibility:hidden;
  border:1px solid white;
}
.bukkan1{background:transparent url('images/kep1.jpg') no-repeat center center;}
.bukkan2{background:transparent url('images/kep7.jpg') no-repeat  center center;}
.bukkan3{background:transparent url('images/kep10.jpg') no-repeat  center center;}
li a:hover .bukkan1, li a:hover .bukkan2, li a:hover .bukkan3{visibility:visible;}
/* menü felbukkanó kép */

/* div-ek listája */
.cdivsk{
  margin:0;padding:0;
  width: 80px;
  margin-bottom:5px;
}
div#rcsk{
  -moz-column-width: 80px;
  -webkit-column-width: 80px;
  column-width: 80px;
  -moz-column-rule-width: 5px;
  -webkit-column-rule-width: 5px;
  column-rule-width: 5px;
  -moz-column-gap: 5px;
  -webkit-column-gap: 5px;
  column-gap: 5px;
  height: 100%;
  overflow: visible;
  column-fill: balance;
  background-color:black;
  margin:0;padding:0;
}
/* div-ek listája */

/* Egyedi Checkbox */
div#egyedi{
 width:250px;
 margin:0;
 padding:0;
}
/*label + p, input + p{margin-top:20px;}*/
p:not(#foo) > input{
	padding: 0;
	margin: 0;
	height: 16px;
	width: 16px;
	float: left;
	position: absolute;
	left: 0;
	opacity: 0;
}
p:not(#foo) > label{ 
	float: left; 
	line-height: 16px; 
	color: #fff; 
	padding: 0 0 0 22px;
margin: 0;
  /* átmenet */
	-moz-transition: color 1s ease; 
	-o-transition: color 1s ease; 
	-webkit-transition: color 1s ease; 
	transition: color 1s ease; 
}
p:not(#foo) > input:hover + label, p:not(#foo) > input:focus + label,
p:not(#foo) > input + label:hover, p:not(#foo) > input:focus + label{
  text-shadow:1px 1px 3px red;
  color: green;
}

p:not(#foo) > input + label{
	background: url('images/gr_custom-inputs.png') no-repeat 0 -1px;
	height: 16px;
}
p:not(#foo) > input[type=radio] + label{ background-position: 0 -161px; }
/* Checked styles */
p:not(#foo) > input[type=radio]:checked + label{ background-position: 0 -241px; }
p:not(#foo) > input[type=radio]:hover:checked + label,
p:not(#foo) > input[type=radio]:focus:checked + label,
p:not(#foo) > input[type=radio]:checked + label:hover,
p:not(#foo) > input[type=radio]:focus:checked + label{ background-position: 0 -261px; }
/* Hover & Focus styles */
p:not(#foo) > input[type=radio]:hover + label,
p:not(#foo) > input[type=radio]:focus + label,
p:not(#foo) > input[type=radio] + label:hover{ background-position: 0 -181px; }
/* Active styles */
p:not(#foo) > input[type=radio]:active + label,
p:not(#foo) > input[type=radio] + label:hover:active{ background-position: 0 -201px; }
p:not(#foo) > input[type=radio]:active:checked + label,
p:not(#foo) > input[type=radio]:checked + label:hover:active{ background-position: 0 -281px; }
/* Disabled styles */
p:not(#foo) > input[type=radio]:disabled + label,
p:not(#foo) > input[type=radio]:hover:disabled + label,
p:not(#foo) > input[type=radio]:focus:disabled + label,
p:not(#foo) > input[type=radio]:disabled + label:hover,
p:not(#foo) > input[type=radio]:disabled + label:hover:active{ background-position: 0 -221px; }
p:not(#foo) > input[type=radio]:disabled:checked + label,
p:not(#foo) > input[type=radio]:hover:disabled:checked + label,
p:not(#foo) > input[type=radio]:focus:disabled:checked + label,
p:not(#foo) > input[type=radio]:disabled:checked + label:hover,
p:not(#foo) > input[type=radio]:disabled:checked + label:hover:active{ background-position: 0 -301px; }
/* Egyedi Checkbox */
</style>
<script type="text/javascript">
function letolt_ido()
{
  var kezd = "<?php echo $start_time; ?>";
  var d = new Date();
  var veg = d.getTime();  //milliseconds
  var kulonbseg = veg-kezd;
  kulonbseg = kulonbseg/1000;
  document.getElementById('letolt').innerHTML = 'Az oldal <span style="color:red;">"'+kulonbseg.toFixed(3)+'"<\/span> s alatt töltődött le.';
}
/* DIV Képek-sorok függőleges léptetés */  //Úsztató Galéria:http://coffeescripter.com/code/ad-gallery/
var aktual = 0;
function fol_leptet(sorok_szama)
{
 if (aktual < sorok_szama-1)
 {
   aktual = aktual+1;
   document.getElementById('belso').style.top = '-'+(aktual*80)+'px';
 }
}
function le_leptet(sorok_szama)
{
 if (aktual > 0)
 {
   aktual = aktual-1;
   document.getElementById('belso').style.top = '-'+(aktual*80)+'px';
 }
}
/* DIV Képek-sorok függőleges léptetés */
/* Képek horizontális szkrollozása DIV-el */
var aktual1 = 0;
function jobb_leptet(kepek_szama)
{
 if (aktual1 < ((kepek_szama-1)*70))
 {
   aktual1 = aktual1+1;
   document.getElementById('belso_h').style.left = '-'+(aktual1*1)+'px';
 }
}
function bal_leptet(kepek_szama)
{
 if (aktual1 > 0)
 {
   aktual1 = aktual1-1;
   document.getElementById('belso_h').style.left = '-'+(aktual1*1)+'px';
 }
}
var lepes;
var egy_ciklus = 0;
function megall()
{ clearTimeout(lepes); }
function jobbra(kepek_szama)
{
  jobb_leptet(kepek_szama);
  if (egy_ciklus < 70)
  {
    lepes = setTimeout("jobbra("+kepek_szama+");", 10);
    egy_ciklus = egy_ciklus+1;
  }
  if (egy_ciklus == 70)
  {
    megall();
    egy_ciklus = 0;
  }
}
function balra(kepek_szama)
{
  bal_leptet(kepek_szama);
  if (egy_ciklus < 70)
  {
    lepes = setTimeout("balra("+kepek_szama+");", 10);
    egy_ciklus = egy_ciklus+1;
  }
  if (egy_ciklus == 70)
  {
    megall();
    egy_ciklus = 0;
  }
}
/* Képek horizontális szkrollozása DIV-el */
/* Képek horizontális szkrollozása DIV-el -> A "Tovább lépés gomb(Ciril)" kérdése kapcsán... */
var aktual2 = 0;
function jobb_leptet2(kepek_szama)
{
 if (aktual2 < ((kepek_szama-3)*142))
 {
   aktual2 = aktual2+3;
   document.getElementById('belso_h2').style.left = '-'+(aktual2*1)+'px';
 }
}
function bal_leptet2(kepek_szama)
{
 if (aktual2 > 0)
 {
   aktual2 = aktual2-3;
   document.getElementById('belso_h2').style.left = '-'+(aktual2*1)+'px';
 }
}
var lepes2;
var egy_ciklus2 = 0;
function megall2()
{ clearTimeout(lepes2); }
function jobbra2(kepek_szama)
{
  jobb_leptet2(kepek_szama);
  if (egy_ciklus2 < 142)
  {
    lepes2 = setTimeout("jobbra2("+kepek_szama+");", 10);
    egy_ciklus2 = egy_ciklus2+1;
  }
  if (egy_ciklus2 == 142)
  {
    megall2();
    egy_ciklus2 = 0;
  }
}
function balra2(kepek_szama)
{
  bal_leptet2(kepek_szama);
  if (egy_ciklus2 < 142)
  {
    lepes2 = setTimeout("balra2("+kepek_szama+");", 10);
    egy_ciklus2 = egy_ciklus2+1;
  }
  if (egy_ciklus2 == 142)
  {
    megall2();
    egy_ciklus2 = 0;
  }
}
/* Képek horizontális szkrollozása DIV-el -> A "Tovább lépés gomb(Ciril)" kérdése kapcsán... */
</script>
  <link rel="stylesheet" type="text/css" media="all" href="scripts/jScrollPane.css" />
	<script type="text/javascript" src="scripts/jquery-1.2.6.min.js"></script>
	<script type="text/javascript" src="scripts/jquery.mousewheel.js"></script>
	<script type="text/javascript" src="scripts/jScrollPane.js"></script>
<script type="text/javascript">
	$(function()
	{
		$('#pane4').jScrollPane({scrollbarWidth:20, scrollbarMargin:10});
		$('#add-content').bind(
			'click',
			function()
			{ $('#pane4').append($('<p><\/p>').html($('#intro').html())).jScrollPane({scrollbarWidth:20, scrollbarMargin:10}); }
		);
		$('#remove-content').bind(
			'click',
			function()
			{ $('#pane4').empty().append($('<p><\/p>').html($('#intro').html())).jScrollPane({scrollbarWidth:20, scrollbarMargin:10}); }
		);
	});
</script>
<style type="text/css" media="screen">
.holder {
  margin:10px;
}
/* scroll panel*/
.scroll-pane {
	width: 380px;
	height: 200px;
	overflow: auto;
	background: #ccc;
}
#pane4 {
	height: 190px;
}
/* scrollsáv háttér */
.orange-bar .jScrollPaneTrack {
  background: -moz-linear-gradient(#FF6600, #ffffff);
  background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#FF6600), to(#ffffff));
  background: -webkit-linear-gradient(#FF6600, #ffffff); 
  background: -o-linear-gradient(#FF6600, #ffffff);
  -pie-background: linear-gradient(#FF6600, #ffffff);
  behavior: url('pie.htc');
}
/* csúszka */
.orange-bar .jScrollPaneDrag {
	background: #933A00 url('scripts/drag_grab_o.gif') no-repeat 50% 50%;
}
/* tartalom háttér */
.orange-bar .scroll-pane {
	background: #FFDFCA;
}
</style>
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="../minw_ie.css" media="screen" /><![endif]-->
</head>
<body onload="letolt_ido();">
<!-- Fixed dinamikus háttérkép -->
<img id="oldal-hatter" src="../../kepek/kozos/oldal_hatter.jpg" alt="" />
<div id="oldal-keret">
<!-- Fixed dinamikus háttérkép -->
 <div id="oldal">
<!--<div id="example"></div>-->
  <div id="fodiv">
    <div id="head_kozep"> 
      <div id="head_bal"></div>   
      <div id="head_jobb"></div>
    </div>
    <div id="kozep_tartalom">
      <br class="clear" />
      <div id="kozep_bal"></div>
      <div id="kozep_jobb"></div>
      <!-- oldal-tartalom kezdete -->
      <h2 style="text-align:center;">Az oldal kerete, kerekített doboz DIV-el</h2>
      <h4 style="text-align:center;">(Megoldás: Head/Content/Footer blokkoknál is "közép" DIV-ben "left/right" DIV háttérképpekkel)</h4>
      <h5 style="text-align:center;color:white;">(pie.htc IE6-ig nem működik)</h5>
<hr style="width:85%;" />
      <h2 style="text-align:center;">Checkbox-kiválasztás küldés és vissza olvasás PHP-val</h2>
      <form name="formom" method="post" action="" enctype="multipart/form-data" style="width:100px;margin:0 auto;text-align:left;">
        Ásványvíz:<input type="checkbox" name="asvanyviz" value="ásványviz" /><br />
        Üdítő:<input type="checkbox" name="udito" value="üdítő" /><br />
        Kávé:<input type="checkbox" name="kave" value="kávé" /><br />
        <button type="submit" >Elküld</button>
      </form>
      <div style="width:240px;margin:0 auto;">
      <?php
        echo '<b>Egyes módszer eredménye:</b><br />';
        $asvanyviz = isset($_POST["asvanyviz"])? $_POST["asvanyviz"] : "";
        $udito = isset($_POST["udito"])? $_POST["udito"] : "";
        $kave = isset($_POST["kave"])? $_POST["kave"] : "";
        echo $asvanyviz.' - '.$udito.' - '.$kave.'<br />';
        echo '<b>Kettes módszer eredménye:</b><br />';
        $asvanyviz1 = isset($_POST["asvanyviz"])? true : false;
        $udito1 = isset($_POST["udito"])? true : false;
        $kave1 = isset($_POST["kave"])? true : false;
        if ($asvanyviz1)
          echo "kell ásványvíz - ";
        if ($udito1)
          echo "kell üdítő - ";
        if ($kave1)
          echo "kell kávé - ";
      ?>
      </div>
<hr style="width:85%;" />
      <div style="width:640px;margin:0 auto;text-align:center;">
      <?php
        print "<h2>PHP:kép generálása(Lomtároló)</h2>";
        if(!isset($_POST['text1']) && !isset($_POST['text2']) && !isset($_POST['text3']))
        {
      ?>
        <form action="" method="post">
          Szöveg1 a képre(max. 14 kar.):&nbsp;<input type="text" maxlength="14" name="text1" /><br />
          Szöveg2 a képre(max. 20 kar.):&nbsp;<input type="text" maxlength="20" name="text2" /><br />
          Szöveg3 a képre(max. 10 kar.):&nbsp;<input type="text" maxlength="10" name="text3" /><br />
          <input type="submit" />
        </form>
      <?php
          echo '<br /><img src="images/1.jpg" alt="Lomtároló GD-alap" title="Lomtároló GD-alap" /><br />';
        }
        else
        {
      ?>
        <!-- ez csak azért, hogy a próbák során ne kelljen mindig frissíteni -->
        <form action="" method="post">
          Szöveg1 a képre(max. 14 kar.):&nbsp;<input type="text" maxlength="14" name="text1" /><br />
          Szöveg2 a képre(max. 20 kar.):&nbsp;<input type="text" maxlength="20" name="text2" /><br />
          Szöveg3 a képre(max. 10 kar.):&nbsp;<input type="text" maxlength="10" name="text3" /><br />
          <input type="submit" />
        </form>
      <?php
          $string1 = $_POST['text1'];
          $string2 = $_POST['text2'];
          $string3 = $_POST['text3'];
          $im = imagecreatefromjpeg("images/1.jpg");
          $font_size1 = 16;
          $font_size2 = 10;
          $font_size3 = 20;
          //$font_file = getcwd() .'/arial.ttf';
          $font_file1 = 'font/FLbrsa1.ttf';
          $font_file2 = 'font/arial.ttf';
          $font_file3 = 'font/Century.ttf';
          //Teljes szöveg befoglaló téglalap kalkulációk
          //$top_px1 = (imagesx($im) - 9.5 * strlen($string1)) / 2;
          //$top_px2 = (imagesx($im) - 9.5 * strlen($string2)) / 2;
          //$top_px3 = (imagesx($im) - 9.5 * strlen($string3)) / 2;
          $_bx1 = imageTTFBbox($font_size1, 0 , $font_file1, $string1); 
          $W1 = abs($_bx1[2]-$_bx1[0]); //jobb alsó - bal alsó sarok X koordináta
          $top_px1 = (imagesx($im) - $W1) / 2;
          $_bx2 = imageTTFBbox($font_size2, 0 , $font_file2, $string2); 
          $W2 = abs($_bx2[2]-$_bx2[0]); //jobb alsó - bal alsó sarok X koordináta
          $top_px2 = (imagesx($im) - $W2) / 2;
          $_bx3 = imageTTFBbox($font_size3, 0 , $font_file3, $string3); 
          $W3 = abs($_bx3[2]-$_bx3[0]); //jobb alsó - bal alsó sarok X koordináta
          $top_px3 = (imagesx($im) - $W3) / 2;
          //Színek
          $black = imagecolorallocate($im, 0x00, 0x00, 0x00);
          $red = imagecolorallocate($im, 0xFF, 0x00, 0x00);
          $green = imagecolorallocate($im, 0x00, 0xFF, 0x00);
          //$string1 = iconv("UTF-8", "Latin2", $string);  //valószínű ez a sor is kell az elfogadott megoldáshoz!!!
          //imagestring($im, 5, $top_px, 155, $string1, $black);
          imagefttext($im, $font_size1, 0, $top_px1, 165, $black, $font_file1, $string1);
          imagefttext($im, $font_size2, 0, $top_px2, 225, $red, $font_file2, $string2);
          imagefttext($im, $font_size3, 0, $top_px3, 265, $green, $font_file3, $string3);
          //a mentés és megjelenítés
          imagejpeg($im, 'images/2.jpg');
          echo '<br /><img src="images/2.jpg" alt="Lomtároló GD-alap + szöveg" title="Lomtároló GD-alap + szöveg" /><br />';
          imagedestroy($im);
        }
      ?>
      </div>
<hr style="width:85%;" />
      <h2 style="text-align:center;">IMG időzítve váltás inditás(Zee)</h2>
      <?php
        $kepek = array('images/02.jpg','images/03.jpg','images/04.jpg','images/05.jpg','images/06.jpg');
      ?>
      <script type="text/javascript">
        var repeat;
        var images = new Array('<?php echo implode("', '", $kepek); ?>');
        var index = 0;
        function indit()
        { valtogat(index); }
        function leallit()
        { 
          clearTimeout(repeat);
          index = 0;
        }
        function valtogat(index)
        {
          $("#slideShow").attr("src", images[index]);
          ++index;
          if(index >= images.length)
          { index = 0; }
          repeat = setTimeout("valtogat("+index+")",2000);
        }
      </script>
      <div style="width:480px;margin:0 auto;text-align:center;">
      <?php
        echo '<img id="slideShow" src="images/02.jpg" border="0" onmouseover="leallit();" onmouseout="indit();" style="cursor:pointer;" title="Leállítva" alt="" />';
      ?>
        <br /><br />
        <button onclick="indit();">Indít</button>&nbsp;&nbsp;&nbsp;<button onclick="leallit();">Leállít</button>
      </div>
<hr style="width:85%;" />
      <h2 style="text-align:center;">Egyedi "Scrollbars(szín átmenettel)"</h2>
      <div style="width:400px;margin:0 auto;">
		   <div class="holder orange-bar">
			  <div id="pane4" class="scroll-pane">
				 <p>&gt;Lorem ipsum dolor sit amet.&lt;</p>
				 <p>&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec condimentum pretium nisl. Integer quis tellus nec turpis placerat scelerisque. In semper lacus eu nisi. Praesent dignissim metus sit amet enim. Nam auctor, neque semper congue sagittis, risus mi commodo pede, nec euismod magna libero at sem. In enim magna, vestibulum et, blandit sit amet, tempor vel, ligula. Phasellus ante augue, congue vitae, faucibus quis, gravida sit amet, diam. Nullam congue accumsan magna. Etiam a nunc. Aliquam elit urna, ornare vitae, ultrices et, tempus non, nisl. Duis eros neque, luctus quis, interdum ultricies, auctor eu, urna. Donec nibh. Integer in purus tempus mi venenatis mollis. Cras nunc odio, porttitor at, accumsan ac, adipiscing vitae, ante.</p>
				 <p>Nam dui enim, fringilla vitae, rhoncus non, pharetra in, nunc. Sed a lectus vel orci bibendum placerat. Aliquam erat volutpat. Integer odio. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis dictum egestas lorem. Donec ultricies volutpat tellus. Phasellus justo arcu, pharetra eget, cursus non, consectetuer ac, nunc. Fusce orci tortor, semper vel, lacinia vitae, accumsan id, quam. Mauris semper molestie lectus. Duis venenatis erat ultrices nisl.</p>
				 <p>Morbi augue enim, ultricies nec, lobortis sed, iaculis eu, quam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Curabitur sollicitudin, elit eu porttitor varius, tellus velit tristique sem, vitae blandit nisi eros id purus. Nunc non lorem. Nunc blandit purus nec nisi. Donec vulputate, urna vel interdum tristique, tellus mauris pretium lacus, quis sodales lectus nunc sit amet turpis. Suspendisse potenti. Fusce accumsan. Maecenas aliquam consectetuer augue. Fusce est neque, condimentum nec, condimentum vitae, consectetuer ac, tortor. Praesent ultricies urna in lectus. Nam erat nunc, venenatis nec, facilisis sed, feugiat ac, pede. Vivamus aliquam aliquet libero. Curabitur dolor nunc, scelerisque at, gravida dignissim, rutrum at, orci. Maecenas vitae libero id eros rutrum hendrerit. Duis lacinia mauris non erat. Nullam et dolor vel leo sollicitudin suscipit. Sed laoreet libero.</p>
				 <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent turpis. Suspendisse molestie, neque non congue ullamcorper, neque sem consequat nisl, eget pulvinar odio erat et tellus. Nunc luctus convallis dolor. Nullam non mauris. Etiam nisi magna, adipiscing eu, nonummy ac, laoreet nec, est. Pellentesque tristique, est vel condimentum feugiat, nisi justo rhoncus pede, in pulvinar mauris lectus vitae dui. Pellentesque scelerisque. Vestibulum tellus dolor, porta quis, facilisis nec, convallis vitae, quam. Quisque nisi. Nunc vitae nulla vel turpis mollis molestie. Etiam vitae massa.&lt;</p>
			  </div>
		   </div>
      </div>
<hr style="width:85%;" />
      <h2 style="text-align:center;">Képek-sorok léptetése DIV-el</h2>
      <h3>("Peet" kattintásra fix px scrollozás kérdéséhez is)</h3>
      <div style="width:490px; height:80px; position:relative; overflow:hidden; margin:0 auto; border:1px solid red;">
        <div id="belso" style="width:490px; position:absolute;left:0px;top:0;">
          <img src="images/kep1.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep2.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep3.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep4.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep5.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep6.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep7.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep8.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep9.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep10.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep11.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep12.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep13.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep14.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep15.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep16.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep17.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep18.jpg" width="70" height="80" style="float:left;" alt="" />
        </div>
      </div>
      <div style="width:160px;margin:0 auto;">
        <button onclick="fol_leptet(3)">Léptet föl</button>
        <button onclick="le_leptet(3)">Léptet le</button>
      </div>
<hr style="width:85%;" />
      <h2 style="text-align:center;">Képek horizontális szkrollozása DIV-el</h2>
      <h3>("formaa" Slideshow kép csúsztatása kérdéséhez is)</h3>
      <div style="width:70px; height:80px; position:relative; overflow:hidden; margin:0 auto; border:1px solid red;">
        <div id="belso_h" style="width:1260px;height:80px; position:absolute;left:0;top:0;">
          <img src="images/kep1.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep2.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep3.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep4.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep5.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep6.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep7.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep8.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep9.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep10.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep11.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep12.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep13.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep14.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep15.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep16.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep17.jpg" width="70" height="80" style="float:left;" alt="" />
          <img src="images/kep18.jpg" width="70" height="80" style="float:left;" alt="" />
        </div>
      </div>
      <div style="width:240px;margin:0 auto;">
        <button onclick="jobbra(18);">Léptet jobbra</button>
        <button onclick="balra(18);">Léptet balra</button>
      </div>
<hr style="width:85%;" />
      <h3 style="text-align:center;">A "Tovább lépés gomb(Ciril)" kérdése kapcsán...</h3>
      <div style="width:426px; height:162px; position:relative; overflow:hidden; margin:0 auto; border:1px solid black;">
        <div id="belso_h2" style="width:2556px;height:162px; position:absolute;left:0px;top:0px;">
          <img src="images/kep1.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép1" />
          <img src="images/kep2.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép2" />
          <img src="images/kep3.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép3" />
          <img src="images/kep4.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép4" />
          <img src="images/kep5.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép5" />
          <img src="images/kep6.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép6" />
          <img src="images/kep7.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép7" />
          <img src="images/kep8.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép8" />
          <img src="images/kep9.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép9" />
          <img src="images/kep10.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép10" />
          <img src="images/kep11.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép11" />
          <img src="images/kep12.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép12" />
          <img src="images/kep13.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép13" />
          <img src="images/kep14.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép14" />
          <img src="images/kep15.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép15" />
          <img src="images/kep16.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép16" />
          <img src="images/kep17.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép17" />
          <img src="images/kep18.jpg" width="140" height="160" style="float:left;" alt="" border="1" title="Kép18" />
        </div>
      </div>
      <div style="width:300px;margin:0 auto;">
        <button onclick="jobbra2(18);">Léptet jobbra hármat</button>
        <button onclick="balra2(18);">Léptet balra hármat</button>
      </div>
<hr style="width:85%;" />
      <div style="width:640px;margin:0 auto;text-align:center;">
      <?php
        print "<h2>Rajzolás php-val(vagesz06)</h2>";
        // Megadjuk a kép méretét
        $kep = imagecreate(200,200);
        //Megadjuk a kép háttérszínét és/vagy átlátszóságot
        $opacity_hatter = imagecolorallocatealpha ($kep, 0, 0, 0, 127);
        imagefill($kep, 0, 0, $opacity_hatter);
        //$hatter = imagecolorallocate($kep, 255,255,255);
        // Létrehozunk egy kék színt
        $kek = imagecolorallocate($kep, 0, 0, 225);
        //Létrehoznk egy kék színű körívet, a középpontja 99,99 koordinátáknál van, 
        //a magassága és szélessége 180,180 képpontnyi. 0 foktól (3 órától) kezdődik és 360 fokkal bezárja a kört. 
        //A színe pedig az előzőleg létrehozott kék.
        imagefilledarc($kep, 99, 99, 180, 180, 0, 36, $kek, IMG_ARC_PIE);
        // Létrehozunk egy piros színt
        $piros = imagecolorallocate($kep, 225, 0, 0);
        imagefilledarc($kep, 99, 99, 180, 180, 36, 198, $piros, IMG_ARC_PIE);
        // Létrehozunk egy zold színt
        $zold = imagecolorallocate($kep, 0, 255, 0);
        imagefilledarc($kep, 99, 99, 180, 180, 198, 360, $zold, IMG_ARC_PIE);
        $szoveg = "10%";
        $szin=imagecolorallocate($kep, 255, 255, 255);
        imagestring($kep, 3, 150, 112, $szoveg, $szin);
        $szoveg2 = "45%";
        imagestring($kep, 3, 70, 140, $szoveg2, $szin);
        imagestring($kep, 3, 100, 50, $szoveg2, $szin);
        // létrehozza a kész képet ésmegjeleníti
        imagepng($kep, "images/vagesz06.png");
        echo '<br /><img src="images/vagesz06.png" alt="vagesz06 GD-rajza" title="vagesz06 GD-rajza" /><br />';
        // törli a memóriáblól a képet
        imagedestroy($kep);
      ?>
      </div>
<hr style="width:85%;" />
      <!--  
        http://www.w3schools.com/css3/css3_transitions.asp
        http://www.w3schools.com/css3/css3_pr_transition-timing-function.asp
      -->
      <h2 style="text-align:center;">Egyedi Checkbox</h2>
      <h5 style="text-align:center;color:white;">(IE8-ig nem működik)</h5>
      <div id="egyedi">
        <div>
          <form method="post" action="">
            <div>
              <div>
                <label for="ar1[]">Csatorna díjak:</label>
              </div>
              <div>
                <p><input type="radio" value="male" id="male1" name="gender" /> <label for="male">D9835 / 258 USD+ÁFA</label></p>
                <br style="clear:both;height:0;" />
                <p><input type="radio" value="male" id="male2" name="gender" /> <label for="male">D9850 / 955 USD+ÁFA</label></p>
                <br style="clear:both;height:0;" />
                <p><input type="radio" value="male" id="male3" name="gender" /> <label for="male">D9850SDI / 1495 USD+ÁFA</label></p>
                <br style="clear:both;height:0;" />
                <p><input type="radio" value="male" id="male4" name="gender" /> <label for="male">D9850SDI / 1495 USD+ÁFA</label></p>
                <br style="clear:both;height:0;" />
              </div>
            </div>
          </form>
        </div>
      </div>
<hr style="width:85%;" />
      <!--  -->
      <h2 style="text-align:center;">Menü, felbukkanó kép</h2>
      <div style="width:400px;margin:0 auto;">
        <ul>
          <li><a href="#">Menüpont1<span class="bukkan1" style="">&nbsp;</span></a></li>
          <li><a href="#">Menüpont2<span class="bukkan2" style="">&nbsp;</span></a></li>
          <li><a href="#">Menüpont3<span class="bukkan3" style="">&nbsp;</span></a></li>
        </ul>
      </div>
      <!--  -->
<hr style="width:85%;" />
      <h2 style="text-align:center;">80px széles DIV elemek-ek listája</h2>
      <h5 style="text-align:center;color:white;">(IE8-ig nem működik)</h5>
      <br />
      <div id="keret1" style="width:165px;background-color:black;padding:5px;margin:0 auto;">
        <div id="rcsk">
          <div class="cdivsk" style="background-color:blue;height:60px;">Szöveg1</div>
          <div class="cdivsk" style="background-color:brown;height:45px;">Szöveg2</div>
          <div class="cdivsk" style="background-color:red;height:75px;">Szöveg3</div>
          <div class="cdivsk" style="background-color:blue;height:20px;">Szöveg4</div>
          <div class="cdivsk" style="background-color:green;height:60px;">Szöveg5</div>
          <div class="cdivsk" style="background-color:red;height:40px;">Szöveg6</div>
          <div class="cdivsk" style="background-color:white;height:30px;">Szöveg7</div>
          <div class="cdivsk" style="background-color:green;height:25px;">Szöveg8</div>
          <div class="cdivsk" style="background-color:yellow;height:60px;">Szöveg9</div>
          <div class="cdivsk" style="background-color:white;height:40px;">Szöveg10</div>
          <div class="cdivsk" style="background-color:gray;height:30px;">Szöveg11</div>
          <div class="cdivsk" style="background-color:lightgray;height:20px;">Szöveg12</div>
        </div>
      </div>
      <br />
<hr style="width:85%;" />
      <br />
      <div style="width:640px;margin:0 auto;text-align:center;">
       <h2 style="text-align:center;">Tartalom váltás újratöltés nélkül(Vic)</h2>
       <?php echo '<h4 style="text-align:center;">(A pontos idő oldal betöltődéskor: '.date('Y-m-d H:i:s').')</h4>'; ?>
       Menüpontok:&nbsp;<a href="javascript:void(0)" onclick="tartalom()">Bemutatkozás</a>&nbsp;&nbsp;
       <a href="javascript:void(0)" onclick="tartalom(1)">Kapcsolat</a>&nbsp;&nbsp;
       <a href="javascript:void(0)" onclick="tartalom(2)">Statisztika</a>&nbsp;&nbsp;
       <a href="javascript:void(0)" onclick="tartalom(3)">Szabályzat</a>&nbsp;&nbsp;
       <script type="text/javascript">
         function tartalom(sorszam)
         {
           var elem=document.getElementById("valtozo_div");
           switch (sorszam)
           {
             case 1:
               elem.innerHTML="Kapcsolat...";
               break;
             case 2:
               elem.innerHTML="Oldal statisztika...";
               break;
             case 3:
               elem.innerHTML="Szabályzat...";
               break;
             default:
               elem.innerHTML="<?php include 'bemutatkozas.php'; ?>";
           }
        }
      </script>
       <br /><br />
       <div style="width:600px;margin:0 auto;text-align:center;border:1px solid red;" id="valtozo_div">Változó tartalom helye</div>
       <br />
      </div>
<hr style="width:85%;" />
      <h2 style="text-align:center;">PHP/JS letöltés mérés</h2>
      <div id="letolt" style="text-align:center;margin:0;padding:0;color:white;font-weight:700;">&nbsp;</div>
<hr style="width:85%;" />
      <h3 style="text-align:center;"><a href="../proghu_teszt.php" style="color:black;">Vissza a TESZTEK-re</a></h3>
<hr style="width:85%;" />
      <!-- oldal-tartalom vége -->
      <br class="clear" />
    </div>
    <div id="footer_kozep">
      <div id="footer_bal"></div>
      <div id="footer_jobb"></div>
      <br class="clear" />
    </div>
  </div>
 </div>
</div>
</body>
</html>
